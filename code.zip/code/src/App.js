import "./App.css";
import Container from "react-bootstrap/Container";
import Row from "react-bootstrap/Row";
import Col from "react-bootstrap/Col";
import Nav from "react-bootstrap/Nav";
import Button from "react-bootstrap/Button";
import Form from "react-bootstrap/Form";
import Modal from "react-bootstrap/Modal";
import { useState } from "react";
import Table from "react-bootstrap/Table";

function App() {
  const [show, setShow] = useState(false);

  const handleClose = () => setShow(false);
  const handleShow = () => setShow(true);
  return (
    <div className="App">
      <header className="App-header">
        <Container className="custom-button main-wp bg-white">
          <Row>
            <Col>
              <Nav justify variant="tabs" defaultActiveKey="/home">
                <Nav.Item>
                  <Nav.Link href="/home">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="33"
                      height="32"
                      viewBox="0 0 33 32"
                      fill="none"
                    >
                      <g clip-path="url(#clip0_3260_1823)">
                        <path
                          d="M30.8572 4H6.85718C6.32674 4 5.81804 4.21071 5.44296 4.58579C5.06789 4.96086 4.85718 5.46957 4.85718 6V8H2.85718C2.32674 8 1.81804 8.21071 1.44296 8.58579C1.06789 8.96086 0.857178 9.46957 0.857178 10L0.857178 26C0.857178 26.5304 1.06789 27.0391 1.44296 27.4142C1.81804 27.7893 2.32674 28 2.85718 28H26.8572C27.3876 28 27.8963 27.7893 28.2714 27.4142C28.6465 27.0391 28.8572 26.5304 28.8572 26V24H30.8572C31.3876 24 31.8963 23.7893 32.2714 23.4142C32.6465 23.0391 32.8572 22.5304 32.8572 22V6C32.8572 5.46957 32.6465 4.96086 32.2714 4.58579C31.8963 4.21071 31.3876 4 30.8572 4ZM26.8572 26H2.85718V10H26.8572V26ZM30.8572 22H28.8572V10C28.8572 9.46957 28.6465 8.96086 28.2714 8.58579C27.8963 8.21071 27.3876 8 26.8572 8H6.85718V6H30.8572V22Z"
                          fill="#D81B2A"
                        />
                        <path
                          d="M14.8572 24C16.0439 24 17.2039 23.6481 18.1906 22.9888C19.1773 22.3295 19.9463 21.3925 20.4005 20.2961C20.8546 19.1997 20.9734 17.9933 20.7419 16.8295C20.5104 15.6656 19.9389 14.5965 19.0998 13.7574C18.2607 12.9182 17.1916 12.3468 16.0277 12.1153C14.8638 11.8838 13.6574 12.0026 12.5611 12.4567C11.4647 12.9109 10.5276 13.6799 9.86836 14.6666C9.20907 15.6533 8.85718 16.8133 8.85718 18C8.85718 19.5913 9.48932 21.1174 10.6145 22.2426C11.7398 23.3679 13.2659 24 14.8572 24ZM14.8572 14C15.6483 14 16.4217 14.2346 17.0795 14.6741C17.7373 15.1136 18.2499 15.7384 18.5527 16.4693C18.8554 17.2002 18.9347 18.0044 18.7803 18.7804C18.626 19.5563 18.245 20.269 17.6856 20.8284C17.1262 21.3878 16.4135 21.7688 15.6375 21.9231C14.8616 22.0775 14.0573 21.9983 13.3264 21.6955C12.5955 21.3928 11.9708 20.8801 11.5313 20.2223C11.0918 19.5645 10.8572 18.7911 10.8572 18C10.8572 16.9391 11.2786 15.9217 12.0288 15.1716C12.7789 14.4214 13.7963 14 14.8572 14Z"
                          fill="#D81B2A"
                        />
                        <path
                          d="M24.8572 17H22.8572V19H24.8572V17Z"
                          fill="#D81B2A"
                        />
                        <path
                          d="M6.85718 17H4.85718V19H6.85718V17Z"
                          fill="#D81B2A"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_3260_1823">
                          <rect
                            width="32"
                            height="32"
                            fill="white"
                            transform="translate(0.857178)"
                          />
                        </clipPath>
                      </defs>
                    </svg>
                    Building <span>(Billing Department)</span>
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="link-1">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="33"
                      height="32"
                      viewBox="0 0 33 32"
                      fill="none"
                    >
                      <g clip-path="url(#clip0_3260_1831)">
                        <path
                          d="M26.8572 14.0029H23.8572V11.3359C23.8572 6.92494 20.2682 3.33594 15.8572 3.33594C11.4462 3.33594 7.85718 6.92494 7.85718 11.3359V14.0029H4.85718C4.30518 14.0029 3.85718 14.4509 3.85718 15.0029C3.85718 15.5549 4.30518 16.0029 4.85718 16.0029H25.8572V28.0029H5.85718V19.0029C5.85718 18.4499 5.40918 18.0029 4.85718 18.0029C4.30518 18.0029 3.85718 18.4499 3.85718 19.0029V29.0029C3.85718 29.5559 4.30518 30.0029 4.85718 30.0029H26.8572C27.4102 30.0029 27.8572 29.5559 27.8572 29.0029V15.0029C27.8572 14.4509 27.4102 14.0029 26.8572 14.0029ZM9.85718 11.3359C9.85718 8.02694 12.5482 5.33594 15.8572 5.33594C19.1662 5.33594 21.8572 8.02694 21.8572 11.3359V14.0029H9.85718V11.3359Z"
                          fill="black"
                        />
                        <path
                          d="M19.8572 22.0029C19.8572 19.7969 18.0632 18.0029 15.8572 18.0029C13.6512 18.0029 11.8572 19.7969 11.8572 22.0029C11.8572 24.2089 13.6512 26.0029 15.8572 26.0029C18.0632 26.0029 19.8572 24.2089 19.8572 22.0029ZM13.8572 22.0029C13.8572 20.8999 14.7542 20.0029 15.8572 20.0029C16.9602 20.0029 17.8572 20.8999 17.8572 22.0029C17.8572 23.1059 16.9602 24.0029 15.8572 24.0029C14.7542 24.0029 13.8572 23.1059 13.8572 22.0029Z"
                          fill="black"
                        />
                      </g>
                      <defs>
                        <clipPath id="clip0_3260_1831">
                          <rect
                            width="32"
                            height="32"
                            fill="white"
                            transform="translate(0.857178)"
                          />
                        </clipPath>
                      </defs>
                    </svg>{" "}
                    Building <span>(Registration Department)</span>
                  </Nav.Link>
                </Nav.Item>
                <Nav.Item>
                  <Nav.Link eventKey="link-2">
                    <svg
                      xmlns="http://www.w3.org/2000/svg"
                      width="24"
                      height="28"
                      viewBox="0 0 24 28"
                      fill="none"
                    >
                      <path
                        d="M22.7198 22.21L15.9998 8.76V2H16.9998V0H6.9998V2H7.9998V8.76L1.2798 22.21C0.974905 22.8193 0.830697 23.4964 0.860854 24.1771C0.891011 24.8577 1.09453 25.5194 1.45212 26.0993C1.80971 26.6793 2.30951 27.1583 2.90412 27.4909C3.49874 27.8236 4.16847 27.9988 4.8498 28H19.1498C19.8311 27.9988 20.5009 27.8236 21.0955 27.4909C21.6901 27.1583 22.1899 26.6793 22.5475 26.0993C22.9051 25.5194 23.1086 24.8577 23.1387 24.1771C23.1689 23.4964 23.0247 22.8193 22.7198 22.21ZM9.8898 9.45C9.96119 9.31068 9.99886 9.15654 9.9998 9V2H13.9998V9C14.0007 9.15654 14.0384 9.31068 14.1098 9.45L18.3798 18H5.6198L9.8898 9.45ZM20.8898 25.05C20.7109 25.3401 20.4608 25.5796 20.1632 25.7459C19.8657 25.9122 19.5306 25.9996 19.1898 26H4.8498C4.51025 25.9981 4.17676 25.9098 3.88076 25.7434C3.58477 25.577 3.33601 25.338 3.15794 25.0489C2.97986 24.7598 2.87833 24.4301 2.86291 24.0908C2.84749 23.7516 2.91869 23.4141 3.0698 23.11L4.6198 20H19.3798L20.9298 23.11C21.0823 23.4135 21.155 23.7509 21.141 24.0904C21.127 24.4298 21.0268 24.76 20.8498 25.05H20.8898Z"
                        fill="black"
                      />
                    </svg>{" "}
                    Building <span>(Lab test Department)</span>
                  </Nav.Link>
                </Nav.Item>
              </Nav>

              <Form className="form-ui">
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Select Counter Number</Form.Label>{" "}
                      <Form.Select required>
                        <option required>Select</option>
                        <option value="1">Counter 1</option>
                        <option value="2">Counter 2</option>
                        <option value="3">Counter 3</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Counter Name</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter Counter Name"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>User Name</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter User Name"
                        required
                      />
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>User Id</Form.Label>
                      <Form.Control
                        type="text"
                        placeholder="Enter User Id"
                        required
                      />
                    </Form.Group>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Type</Form.Label>{" "}
                      <Form.Select>
                        <option>Building</option>
                        <option value="1">Building 1</option>
                        <option value="2">Building 2</option>
                        <option value="3">Building 3</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                  <Col>
                    <Form.Group className="mb-3">
                      <Form.Label>Department</Form.Label>
                      <Form.Select>
                        <option>Select</option>
                        <option value="1">ENT</option>
                        <option value="2">Eye</option>
                        <option value="3">Cardio</option>
                      </Form.Select>
                    </Form.Group>
                  </Col>
                </Row>
                <Button variant="primary" onClick={handleShow}>
                  Save
                </Button>
              </Form>
            </Col>
          </Row>
          <Row>
            <Col>
              <hr class="border border-danger border-2 opacity-50" />
            </Col>
          </Row>

          <Row>
            <Col className="right">
              <Button variant="primary" type="submit">
                New
              </Button>
            </Col>
          </Row>
          <Row>
            <Col>
              <Table striped bordered size="sm">
                <thead>
                  <tr>
                    <th>Counter Number</th>
                    <th>Counter Name</th>
                    <th>User Name</th>
                    <th>User ID</th>
                    <th>Type</th>
                    <th>Department</th>
                    <th>Action</th>
                  </tr>
                </thead>
                <tbody>
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>{" "}
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>{" "}
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>{" "}
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>{" "}
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>{" "}
                  <tr>
                    <td>C1</td>
                    <td>Billing</td>
                    <td>Ashvani Rana</td>
                    <td>#133432SDKH</td>
                    <td>Lab</td>
                    <td>ENT</td>
                    <td>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="20"
                        viewBox="0 0 20 20"
                        fill="none"
                      >
                        <path
                          d="M10 18.1213H19M14.5 1.62132C14.8978 1.2235 15.4374 1 16 1C16.2786 1 16.5544 1.05487 16.8118 1.16148C17.0692 1.26808 17.303 1.42434 17.5 1.62132C17.697 1.8183 17.8532 2.05216 17.9598 2.30953C18.0665 2.5669 18.1213 2.84274 18.1213 3.12132C18.1213 3.3999 18.0665 3.67574 17.9598 3.93311C17.8532 4.19048 17.697 4.42434 17.5 4.62132L5 17.1213L1 18.1213L2 14.1213L14.5 1.62132Z"
                          stroke="#2B5E8C"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                      <svg
                        xmlns="http://www.w3.org/2000/svg"
                        width="20"
                        height="22"
                        viewBox="0 0 20 22"
                        fill="none"
                        className="space"
                      >
                        <path
                          d="M1 5H3M3 5H19M3 5V19C3 19.5304 3.21071 20.0391 3.58579 20.4142C3.96086 20.7893 4.46957 21 5 21H15C15.5304 21 16.0391 20.7893 16.4142 20.4142C16.7893 20.0391 17 19.5304 17 19V5H3ZM6 5V3C6 2.46957 6.21071 1.96086 6.58579 1.58579C6.96086 1.21071 7.46957 1 8 1H12C12.5304 1 13.0391 1.21071 13.4142 1.58579C13.7893 1.96086 14 2.46957 14 3V5M8 10V16M12 10V16"
                          stroke="#DC1919"
                          stroke-width="2"
                          stroke-linecap="round"
                          stroke-linejoin="round"
                        />
                      </svg>
                    </td>
                  </tr>
                  {/* <tr>
                    <td>2</td>
                    <td>Jacob</td>
                    <td>Thornton</td>
                    <td>@fat</td>
                  </tr>
                  <tr>
                    <td>3</td>
                    <td colSpan={2}>Larry the Bird</td>
                    <td>@twitter</td>
                  </tr> */}
                </tbody>
              </Table>
            </Col>
          </Row>
        </Container>

        <Modal
          show={show}
          onHide={handleClose}
          backdrop="static"
          keyboard={false}
        >
          <Modal.Header closeButton>
            <Modal.Title>Building (Billing Department)</Modal.Title>
          </Modal.Header>
          <Modal.Body>Are you sure you want to Save details?</Modal.Body>
          <Modal.Footer>
            <Button variant="secondary" onClick={handleClose}>
              Cancel
            </Button>
            <Button variant="primary">Save</Button>
          </Modal.Footer>
        </Modal>
      </header>
    </div>
  );
}

export default App;
